<?php
header("content-type: text/html;charset=utf-8");
$servername = "localhost:3306";
//$targetId = "billy191";
$username = "root";
$password = "root";
$conn = mysql_connect($servername, $username, $password);
if (!$conn) {
	die("Connection failed: " . mysql_error());
}
mysql_select_db('blog');
mysql_query("set names utf8");
$sql = 'SELECT userid,visited FROM `userinfo` ORDER BY visited DESC';
$retval = mysql_query($sql, $conn);
$arr = array();
$i = 0;
while ($row = mysql_fetch_array($retval, MYSQL_ASSOC)) {
	$arr[$i]['userid'] = $row['userid'];
	$arr[$i]['visited'] = $row['visited'];
	$i += 1;
}
$str = json_encode($arr);
echo "$str";
?>