$(document).ready(function(){
    if ($.cookie('userid') !== null) {
        $('.navbar-text').append("<span style=\"margin-left:10px\">Hello, "+$.cookie('userid')+"</span>");
    }
    else {
        $('.navbar-text').append("<a href=\"#loginModal\" class=\"btn\" data-toggle=\"modal\" data-target=\"#loginModal\" style=\"margin-left:10px;margin-top:0\">Login</a>&nbsp<a href=\"#registerModal\" class=\"btn\" data-toggle=\"modal\" data-target=\"#registerModal\" style=\"margin-left:10px;margin-top:0\">Register</a>");
    }
});
