$(document).ready(function(){
    function getQueryString(name) {
                var reg = new RegExp("(^|&)?"+ name +"=([^&]*)(&|$)");
                var r = window.location.search.substr(1).match(reg);
                if(r!==null)return  unescape(r[2]); return null;
        }
    $.ajax({//浏览量
        type : "POST",
        url : "../v3.1/php/addskim.php",
        data : {
            serial : getQueryString("serial"),
        },
        success : function(json) {
        }
    });
    $.ajax({
        url:"../v3.1/php/getArticle.php",
        type:"POST",
        dataType:"json",
        data: {
            serial : getQueryString("serial"),
        },
        success: function(json) {
            $('#article_title').html(json.title);
            $('title').html(json.title);
            if (json.img !== null)
                $('img').innerHTML="<img src=\""+json.pic+"\" alt=\"\" />";
            //$('#article_text').innerHTML="<p id=\"article_text\">"+json.text+"</p>";
            $('#article_text').html("<p id=\"article_text\">"+json.content+"</p>");
            $.each(json.comment, function(index, item) {
                $('.comments').append("<div><span>"+item.writer+"&nbsp</span><br><span>"+item.content+"</span><a href=\"javascript:void(0)\" onclick=\"reply()\">Reply</a></div><br>");
            });
        }
    });
});

function reply() {
    document.comment.com.focus();
}