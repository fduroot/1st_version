<?php
date_default_timezone_set('prc');
header("content-type: text/html;charset=utf-8");
$serial = $_GET['serial'];
$userId=$_GET['userid'];
$targetId=$_GET['targetId'];
$comment=$_POST['com'];
$searchStuff = urldecode($searchStuff);
$servername = "localhost:3306";
$username = "root";
$password = "root";
$conn = mysql_connect($servername, $username, $password);
if (!$conn) {
	die("Connection failed: " . mysql_error());
}
mysql_select_db('blog');
mysql_query("set names utf8");
if (isset($userId)) {
$time= date('Y-m-d H:i:s');
$sql = "INSERT INTO comments".
"(serial,writer,comment,time)".
"VALUES".
"('$serial','$userId','$comment','$time')";
$retval = mysql_query($sql, $conn);
echo "$sql";
$sql="SELECT comments FROM `article` WHERE serial='$serial'";
$retval=mysql_query($sql,$conn);
$arr=array();
while ($row=mysql_fetch_array($retval,MYSQL_ASSOC)) {
	$arr['comments']=$row['comments'];
}
$co=$arr['comments']+1;
$sql="UPDATE `article` SET comments='$co' WHERE serial='$serial'";
$retval=mysql_query($sql,$conn);
$add='article-page.html?targetId='.$targetId.'&serial='.$serial;
} else {
	echo "<script>alert('你还没有登录，请先登录再评论');</script>";
}
echo "<script>window.location.href='../$add';</script>"	
?>