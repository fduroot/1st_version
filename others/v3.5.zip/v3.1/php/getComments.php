<?php
header("content-type: text/html;charset=utf-8");
$servername = "localhost:3306";
$username = "root";
$password = "root";
$order = $_POST['bookOrder'];
$conn = mysql_connect($servername, $username, $password);
if (!$conn) {
	die("Connection failed: " . mysql_error());
}
$serial = $_POST['serial'];
//echo "Connected successfully";
mysql_select_db('blog');
mysql_query("set names utf8");
$sql = "SELECT comment,writer,time,ord FROM comments WHERE serial='$serial' ORDER BY time DESC";
$retval = mysql_query($sql, $conn);
$arr = array();
$i = 1;
while ($row = mysql_fetch_array($retval, MYSQL_ASSOC)) {
	$arr[$i]['comment'] = $row['comment'];
	$arr[$i]['writer'] = $row['writer'];
	$arr[$i]['time'] = $row['time'];
	$arr[$i]['ord'] = $row['ord'];
	$i += 1;
}
$str = json_encode($arr);
echo $str;
?>