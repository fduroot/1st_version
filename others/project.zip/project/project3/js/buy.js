$(document).ready(function(){
    function getQueryString(name) {
            var reg = new RegExp("(^|&)?"+ name +"=([^&]*)(&|$)");
            var r = window.location.search.substr(1).match(reg);
            if(r!==null)return  unescape(r[2]); return null;
    }
    if(getQueryString("cate")==="all")
        $('#buyall').attr("class","active");
    if(getQueryString("cate")==="ds")
        $('#buyds').attr("class","active");
    if(getQueryString("cate")==="bk")
            $('#buybk').attr("class","active");
    if(getQueryString("cate")==="fd")
            $('#buyfd').attr("class","active");
    if(getQueryString("cate")==="oth")
            $('#buyoth').attr("class","active");
    $.ajax({
        url:"",
        dataType:"json",
        data: {
            page : getQueryString("page"),
            category : getQueryString("cate"),
            bs : "buy"
        },
        success:function(json){
            var page = getQueryString("page");
            if (page==="1")
                $('#prevPage').attr("href","buy.html?cate="+getQueryString("cate")+"page=1");
            else
                $('#prevPage').attr("href","buy.html?cate="+getQueryString("cate")+"page="+(page-1));
            if(page===json.pageNum)
                $('#nextPage').attr("href","buy.html?cate="+getQueryString("cate")+"page="+page);
            else
                $('#nextPage').attr("href","buy.html?cate="+getQueryString("cate")+"page="+(page+1));
            for(var i=page+2; page-i<3; i--)
                if(i>=1 && i<=json.pageNum)
                    $('#prevPage').append("<a style=\"cursor:pointer\" class=\"lead\" href=\"qa.html?page="+i+"\">"+i+"</a>");
            for(var i=0; i<json.passage;i++)
            $.each(json, function(index, item) {
                $('tbody').append("<tr><th class=\"span5\">"+item.title+"</th><th class=\"span2\">"+item.writer+"</th><th class=\"span2\">"+item.time+"</th></tr>");
            });
        }
    });
    /*for test*/
   var page=parseInt(getQueryString("page"));
   //alert(1=="1");
            if (page===1)
                $('#prevPage').attr("href","buy.html?cate="+getQueryString("cate")+"&page=1");
            else
                $('#prevPage').attr("href","buy.html?cate="+getQueryString("cate")+"&page="+(page-1));
            if(page===4)
                $('#nextPage').attr("href","buy.html?cate="+getQueryString("cate")+"&page="+page);
            else
                $('#nextPage').attr("href","buy.html?cate="+getQueryString("cate")+"&page="+(page+1));
            for(var i=page-2; i<=page+2; i++)
                if(i>=1 && i<=4) {
                    if (page==i) $("<a style=\"cursor:pointer\" class=\"lead\" href=\"buy.html?cate="+getQueryString("cate")+"&page="+i+"\"><strong>"+i+"&nbsp</strong></strong>").insertBefore('#nextPage');
                    else $("<a style=\"cursor:pointer\" class=\"lead\" href=\"buy.html?cate="+getQueryString("cate")+"&page="+i+"\">"+i+"&nbsp</a>").insertBefore('#nextPage');
                }
   for (i=0;i<=40;i++) {
   	 if (Math.floor(i/10)+1==page)
   	 $('tbody').append("<tr><th class=\"span5\"><a href=\"article.html?type=buy&cate="+getQueryString("cate")+"&serial="+i+"\">"+"test"+i+"</a></th><th class=\"span2\">"+"anonymous"+"</th><th class=\"span2\">"+"2000/1/1"+"</th></tr>");
   }
    if ($.cookie('userid')===null) {
		$('#edit_btn').attr("href","#loginModal");
		$('#edit_btn').attr("data-toggle","modal");
		$('#edit_btn').attr("data-target","#loginModal");
	} else {
		$('#edit_btn').attr("href", "write.html?targetId=" + para[0][1] + "&style=new&type=buy");
	}

});