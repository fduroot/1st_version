$(document).ready(function() {
    $('#loginForm').bootstrapValidator({
        message: 'This value is not valid',
        feedbackIcons: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {
            account: {
                container: '#logAccError',
                validators: {
                    notEmpty: {
                        message: 'Please enter your account'
                    }
                }
            },
            password: {
                container: '#logPassError',
                validators: {
                    notEmpty: {
                        message: 'Please enter your password'
                    }
                }
            }
        }
    });
});

$(document).ready(function() {
    $('#registerForm').bootstrapValidator({
            message: 'This value is not valid',
            feedbackIcons: {
                valid: 'glyphicon glyphicon-ok',
                invalid: 'glyphicon glyphicon-remove',
                validating: 'glyphicon glyphicon-refresh'
            },
            fields: {
                account: {
                    container: '#regAccError',
                    validators: {
                        notEmpty: {
                            message: 'Please enter your account'
                        },
                        /*callback: {
                          message: 'Invalid account',
                          callback: function(value, validator) {
                            //var acc = validator.getFieldElements('account').val();
                            if (value.length>4) {
                                alert(1);
                                return true;
                            }
                            else
                               return false;
                          }
                        }*/
                    }
                },
                password: {
                    container: '#regPassError',
                    validators: {
                        notEmpty: {
                            message: 'Please enter your password'
                        },
                        callback: {
                            message: 'Invalid password',
                            callback: function(value, validator) {
                                 var pass = validator.getFieldElements('password').val();
                                 if (pass.length>5){
                                      alert(1);
                                      return true;
                                 }
                                 else
                                      return false;
                            }
                        }
                    }
                },
                passwordAgain: {
                    container: '#regPassAgainError',
                    validators: {
                        notEmpty: {
                            message: 'Please confirm your password'
                        }
                        /*callback: {
                                                  message: 'Password does not match',
                                                  callback: function(value, validator) {
                                                    var     pass = validator.getFieldElements('password').val(),
                                                    //   passAgain = validator.getFieldElements('passwordAgain').val();
                                                    if (value===pass) {
                                                        alert(1);
                                                        return true;
                                                    }
                                                    else
                                                        return false;
                                                  }
                                                }*/
                    }
                },
                nickname: {
                    container: '#regNickError',
                    validators: {
                        notEmpty: {
                            message: 'Please enter your nickname'
                        }
                    }
                }
            }
     });
});