$(document).ready(function(){
    if ($.cookie('nickname') !== null) {
    	//$('.navbar-text').hide();
    	//tx=$('.navbar-text').children().first();
        $('.navbar-text').append("<span >Hello, "+$.cookie('userid')+"</span>");
        //$("<span >Hello, "+$.cookie('userid')+"</span>").insertBefore(tx);
    }
    else {
        //alert(1);
        $('.navbar-text').append("<a href=\"#loginModal\" class=\"btn\" data-toggle=\"modal\" data-target=\"#loginModal\">Login</a>&nbsp<a href=\"#registerModal\" class=\"btn\" data-toggle=\"modal\" data-target=\"#registerModal\">Register</a>");
    }
});
