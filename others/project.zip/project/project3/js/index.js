$(document).ready(function() {
	if (parameter[1] !== undefined) {
		para[1] = new Array();
		para[1] = parameter[1].split('=');
		if (para[1][0] == 'userId') {
			$.cookie('userid', para[1][1], {
				expires : 1,
				path : "/"
			});
			window.location.href = "personalindex.html?targetId=" + para[0][1];
		}
	}
});