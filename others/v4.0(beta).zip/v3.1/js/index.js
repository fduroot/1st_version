$(document).ready(function(){
    $.ajax({
            url:"../v3.1/php/getHottest.php",
            dataType:"json",
            data: {
            },
            success:function(json){
                for(var i=0; i<json.slide.passage;i++)
                    $.each(json.slide, function(index, item) {
                         $('.carousel-inner').append("<div class=\"item\"><img alt=\"\" src=\"editor/attached/image/"+item.img+".jpg\"><div class=\"carousel-caption\" contenteditable=\"true\"><h4>"+item.title+"</h4></div></div>");
                    });
                for(var i=0; i<json.sell.passage;i++)
                    $.each(json.sell, function(index, item) {
                        $('#sellHot').append("<div class=\"span12\"><div class=\"span6\"><div class=\"imgContainer\"><img src=\""+item.first.jpg+"\" alt=\"Sorry, this passage doesn't contain an image\" /></div><div><a href=\"article.html?cate=sell&serial="+item.first.serial+"\">"+item.first.title+"</a></div></div><div class=\"span6\"><div class=\"imgContainer\"><img src=\""+item.second.jpg+"\" alt=\"Sorry, this passage doesn't contain an image\" /></div><div><a href=\"article.html?cate=sell&serial="+item.second.serial+"\">"+item.second.title+"</a></div></div></div>");
                    });
                for(var i=0; i<json.buy.passage;i++)
                                    $.each(json.buy, function(index, item) {
                                        $('#buyHot').append("<div class=\"span12\"><div class=\"span6\"><div class=\"imgContainer\"><img src=\""+item.first.jpg+"\" alt=\"Sorry, this passage doesn't contain an image\" /></div><div><a href=\"article.html?cate=buy&serial="+item.first.serial+"\">"+item.first.title+"</a></div></div><div class=\"span6\"><div class=\"imgContainer\"><img src=\""+item.second.jpg+"\" alt=\"Sorry, this passage doesn't contain an image\" /></div><div><a href=\"article.html?cate=buy&serial="+item.second.serial+"\">"+item.second.title+"</a></div></div></div>");
                                    });
                for(var i=0; i<json.intern.passage;i++)
                                    $.each(json.intern, function(index, item) {
                                        $('#internHot').append("<div class=\"span12\"><div class=\"span6\"><div class=\"imgContainer\"><img src=\""+item.first.jpg+"\" alt=\"Sorry, this passage doesn't contain an image\" /></div><div><a href=\"article.html?cate=intern&serial="+item.first.serial+"\">"+item.first.title+"</a></div></div><div class=\"span6\"><div class=\"imgContainer\"><img src=\""+item.second.jpg+"\" alt=\"Sorry, this passage doesn't contain an image\" /></div><div><a href=\"article.html?cate=intern&serial="+item.second.serial+"\">"+item.second.title+"</a></div></div></div>");
                                    });
                for(var i=0; i<json.ptjb.passage;i++)
                                    $.each(json.ptjb, function(index, item) {
                                        $('#ptjbHot').append("<div class=\"span12\"><div class=\"span6\"><div class=\"imgContainer\"><img src=\""+item.first.jpg+"\" alt=\"Sorry, this passage doesn't contain an image\" /></div><div><a href=\"article.html?cate=ptjb&serial="+item.first.serial+"\">"+item.first.title+"</a></div></div><div class=\"span6\"><div class=\"imgContainer\"><img src=\""+item.second.jpg+"\" alt=\"Sorry, this passage doesn't contain an image\" /></div><div><a href=\"article.html?cate=ptjb&serial="+item.second.serial+"\">"+item.second.title+"</a></div></div></div>");
                                    });
                for(var i=0; i<json.stuff.passage;i++)
                                    $.each(json.stuff, function(index, item) {
                                        $('#stuffHot').append("<div class=\"span12\"><div class=\"span6\"><div class=\"imgContainer\"><img src=\""+item.first.jpg+"\" alt=\"Sorry, this passage doesn't contain an image\" /></div><div><a href=\"article.html?cate=stuff&serial="+item.first.serial+"\">"+item.first.title+"</a></div></div><div class=\"span6\"><div class=\"imgContainer\"><img src=\""+item.second.jpg+"\" alt=\"Sorry, this passage doesn't contain an image\" /></div><div><a href=\"article.html?cate=stuff&serial="+item.second.serial+"\">"+item.second.title+"</a></div></div></div>");
                                    });
                for(var i=0; i<json.other.passage;i++)
                                    $.each(json.other, function(index, item) {
                                        $('#otherHot').append("<div class=\"span12\"><div class=\"span6\"><div class=\"imgContainer\"><img src=\""+item.first.jpg+"\" alt=\"Sorry, this passage doesn't contain an image\" /></div><div><a href=\"article.html?cate=other&serial="+item.first.serial+"\">"+item.first.title+"</a></div></div><div class=\"span6\"><div class=\"imgContainer\"><img src=\""+item.second.jpg+"\" alt=\"Sorry, this passage doesn't contain an image\" /></div><div><a href=\"article.html?cate=other&serial="+item.second.serial+"\">"+item.second.title+"</a></div></div></div>");
                                    });
            }
        });
});

function jump(address) {
    window.location.href="topic.html?cate="+address+"&page=1";
}