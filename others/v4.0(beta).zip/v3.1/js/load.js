$(document).ready(function(){
    if ($.cookie('userid') !== null) {
        $('.navbar-text').append("<span style=\"margin-left:10px\">Hello, "+$.cookie('nickname')+"</span>");
        $.ajax({
            url:"../v3.1/php/getCommentNumber.php",
            type:"POST",
            dataType:"json",
            data: {
                userid : $.cookie('userid'),
            },
            success: function(json) {
                $('.navbar-text').append("<ul class=\"nav navbar-nav\" id=\"unreadMessage\"></ul>");
                if(json.newMessageNum === "1")
                    $('#unreadMessage').append("<li class=\"dropdown\"><a data-toggle=\"dropdown\" class=\"dropdown-toggle\" href=\"#\"><span class=\"glyphicon glyphicon-envelope\"></span> "+json.newMessageNum+" new message</a></li>");
                else
                    $('#unreadMessage').append("<li class=\"dropdown\"><a data-toggle=\"dropdown\" class=\"dropdown-toggle\" href=\"#\"><span class=\"glyphicon glyphicon-envelope\"></span> "+json.newMessageNum+" new messages</a></li>");
                $('#unreadMessage li').append("<ul class=\"dropdown-menu\" role=\"menu\"></ul>");
                $.each(json.detail, function(index, item) {
                    $('#unreadMessage li ul').append("<li style=\"width:200px;\"><a href=\"article.html?cate="+item.cate+"&serial="+item.serial+"\">"+item.title+"</li>");
                });
            },
        });
    }
    else {
        $('.navbar-text').append("<a href=\"#loginModal\" class=\"btn\" data-toggle=\"modal\" data-target=\"#loginModal\" style=\"margin-left:10px;margin-top:0\">Login</a>&nbsp<a href=\"#registerModal\" class=\"btn\" data-toggle=\"modal\" data-target=\"#registerModal\" style=\"margin-left:10px;margin-top:0\">Register</a>");
    }
    $('.navbar-text').append("<ul class=\"nav navbar-nav\" id=\"unreadMessage\"></ul>");
    $('#unreadMessage').append("<li class=\"dropdown\"><a data-toggle=\"dropdown\" class=\"dropdown-toggle\" href=\"#\"><span class=\"glyphicon glyphicon-envelope\"></span> "+1+" new comment</a></li>");
    $('#unreadMessage li').append("<ul class=\"dropdown-menu\" role=\"menu\"></ul>");
/*
    $('#unreadMessage li ul').append("<li style=\"width:200px;\"><a href=\"#\" style=\"white-space:normal;word-break:break-all;width:180px;overflow:auto;padding:0 10px 0 10px\">xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx</li>");
    $('#unreadMessage li ul').append("<li style=\"width:200px;\"><a href=\"#\" style=\"white-space:normal;word-break:break-all;width:180px;overflow:auto;padding:0 10px 0 10px\">xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx</li>");
*/
});
