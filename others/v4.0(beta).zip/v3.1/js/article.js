function getQueryString(name) {
    var reg = new RegExp("(^|&)?" + name + "=([^&]*)(&|$)");
    var r = window.location.search.substr(1).match(reg);
    if (r !== null)return unescape(r[2]);
    return null;
}

$(document).ready(function () {
    if ($.cookie('userid') === null)
        $('#nickName').html("<strong>Nickname：</strong><input class=\"input-small\" type=\"text\" name=\"nickname\"/>");
    $.ajax({//评论
        type: "POST",
        url: "../v3.1/php/setRead.php",
        data: {
            serial: getQueryString("serial"),
        },
        success: function (json) {
        }
    });

    $.ajax({//浏览量
        type: "POST",
        url: "../v3.1/php/addskim.php",
        data: {
            serial: getQueryString("serial"),
        },
        success: function (json) {
        }
    });
    $.ajax({
        url: "../v3.1/php/getArticle.php",
        type: "POST",
        dataType: "json",
        data: {
            serial: getQueryString("serial"),
        },
        success: function (json) {
            $('#article_title').html(json.title);
            $('title').html(json.title);
            if (json.img !== null)
                $('img').innerHTML = "<img src=\"" + json.pic + "\" alt=\"\" />";
            //$('#article_text').innerHTML="<p id=\"article_text\">"+json.text+"</p>";
            $('#article_text').html("<p id=\"article_text\">" + json.content + "</p>");
        }
    });
    $.ajax({
        url: "../v3.1/php/getComments.php",
        type: "POST",
        dataType: "json",
        data: {
            serial: getQueryString("serial"),
        },
        success: function (json) {
            $.each(json, function (index, item) {
                $('.comments').append("<div><span>" + item.writer + "&nbsp</span><br><span>" + item.content + "</span><a href=\"javascript:void(0)\" onclick=\"reply(" + item.writer + ")\">Reply</a></div><br>");
            });
        }
    });

});

function reply(writer) {
    if (writer !== null)
        $('#comm').val("To " + writer + " : ");
    document.comment.com.focus();
}

function publish() {
    var commentContent = $('#comm').val();
    var parameter = new Array();
    var to;
    parameter = commentContent.split(' ');
    if (parameter[0] === "To" && parameter[2] === ":")
        to = parameter[1];
    else
        to = null;
    //alert($('#nickName:input').prop('name'));
    $.ajax({
        url: "../v3.1/php/publishComment.php",
        type: "POST",
        data: {
            serial: getQueryString("serial"),
            comment: commentContent,
            to: to,
            cate: getQueryString("cate"),
            //nickname:$('#nickName:input').prop('name'),
        },
        success: function () {
        }
    });
};